#include<stdio.h>  

void main() {  
   
   if (printf("hello world")) {
   }  
} 