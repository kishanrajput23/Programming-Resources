#include <iostream> 
#include<sstream>

using namespace std;

int main ()
{
    char c='A';
    cout.width (5);
    cout<<c;
    return 0;
}
